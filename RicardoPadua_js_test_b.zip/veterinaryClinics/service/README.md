# to start the service run the command
```npm run start```