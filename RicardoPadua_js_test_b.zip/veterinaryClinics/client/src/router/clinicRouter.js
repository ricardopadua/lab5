clinicRouter = Backbone.Router.extend ({
  routes: {
    'show': 'showClinics',
    'details': 'detailsClinics',
  }
});