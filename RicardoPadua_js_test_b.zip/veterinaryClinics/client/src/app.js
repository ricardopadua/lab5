window.clinicManager = {
  Models: {},
  Collections: {},
  Views: {},

  start: function(data) {
    var clinicShow = new clinicCollections(data.clinicCollections),
        router = new clinicRouter();

    router.on('route:clinicShow', function() {
      var clinicView = new clinicView({
        collection: clinicColletion
      });

    });

    router.on('route:clinicDetails', function() {
      var clinicView = new clinicView({
        collection: clinicColletion
      });

    });


  }
};
