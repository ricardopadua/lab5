// following example - http://backbonejs.org/#Collection

clinicColletion = Backbone.Collection.extend({
  model: Clinic
});