// following example - http://backbonejs.org/#Model

clinicModel = Backbone.Model.extend({
  defaults: {
    name: null,
    adress: null,
    tel: null,
    site: null,
    avatar: null
  }
});
